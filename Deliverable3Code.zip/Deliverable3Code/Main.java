package Deliverable3Code;

public class Main {
    public static void main(String[] args) {
        InventoryManager inventoryManager = new InventoryManager();
        System.out.println("Trinket Shop Inventory Manager\nCurrent Inventory:");
        ItemPrinter.printItems(inventoryManager.getItemService().getAllItems());
        inventoryManager.run();
    }
}